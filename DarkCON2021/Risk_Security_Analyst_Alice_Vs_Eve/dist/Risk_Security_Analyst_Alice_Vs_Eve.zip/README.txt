== name ==
Risk Security Analyst Alice Vs Eve

== category ==
crypto

== difficulty ==
medium

== author ==
r3yc0n1c

== description ==
La Casa De Tuple (L.C.D.T) is a Company in Spain which provides their 
own End-to-end encryption services and Alice got a job there. It was 
her first day and her boss told her to manage the **secrets** and 
encrypt the user data with their new End-to-end encryption system. 
You are Eve and you're hired to break into the system. Alice was so 
overconfident that she gave you everyone's keys. Can you break their 
new encryption system and read the chats?
